
public class javademo2 {

}
